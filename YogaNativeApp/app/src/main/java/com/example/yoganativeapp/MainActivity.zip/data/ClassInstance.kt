package com.example.yoganativeapp.data

data class ClassInstance(
    val id: String? = null,
    val yogaClassId: String,
    val date: String,
    val teacher: String,
    val comments: String? = null
)